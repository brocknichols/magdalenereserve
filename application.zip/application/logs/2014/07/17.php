

2014-07-17 14:12:42 - - DEBUG: Executing Controller [blog] action [list] - - ::1 - - blog - - Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 - - http://localhost:8000/magdalene/
2014-07-17 14:12:42 - - DEBUG: No blogs found. - - ::1 - - blog - - Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 - - http://localhost:8000/magdalene/
2014-07-17 14:17:11 - - DEBUG: Executing Controller [welcome] action [welcome] - - ::1 - - / - - Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 - - 