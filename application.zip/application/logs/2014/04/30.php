<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2014-04-30 22:54:49 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:54:49 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:07 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:07 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:42 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:42 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:43 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 22:55:43 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:55 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:55 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:57 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:57 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:59 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:00:59 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:01:29 --- CRITICAL: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt in your bootstrap.php. For more information check the documentation ~ SYSPATH\classes\Kohana\Cookie.php [ 151 ] in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67
2014-04-30 23:01:29 --- DEBUG: #0 C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php(67): Kohana_Cookie::salt('lang', NULL)
#1 C:\xampp\htdocs\magdalene\system\classes\Kohana\Request.php(151): Kohana_Cookie::get('lang')
#2 C:\xampp\htdocs\magdalene\index.php(117): Kohana_Request::factory(true, Array, false)
#3 {main} in C:\xampp\htdocs\magdalene\system\classes\Kohana\Cookie.php:67