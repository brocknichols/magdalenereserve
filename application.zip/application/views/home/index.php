this is a test
<?php
echo $body;