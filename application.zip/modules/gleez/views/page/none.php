<h2><?php echo __('No Pages!') ?></h2>
<p>
	<?php echo __('There are no Pages that have been published.') ?>
</p>
