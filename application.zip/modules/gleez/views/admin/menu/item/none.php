<h3><?php echo __('No Menu Items!') ?></h3>
<p><?php echo __('There are no Menu Items.'); ?></p>
