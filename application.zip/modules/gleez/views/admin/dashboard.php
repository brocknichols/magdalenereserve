<div class="help">
    <p><?php echo __('Welcome to the administration section. Here you may control how your site functions.'); ?></p>
</div>

<div id="dashboard-widgets-wrap" class="row">
    <?php echo $widgets; ?>
</div>