<h3><?php echo __('No Formats!'); ?></h3>
<p><?php echo __('There are no Formats.'); ?></p>
