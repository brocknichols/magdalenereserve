<div class="table-responsive">
	<?php echo $phpinfo; ?>
</div>

<div class="clearfix"></div>