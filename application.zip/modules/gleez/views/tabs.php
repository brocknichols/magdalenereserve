<?php
	echo HTML::tabs($tabs, array('class' => 'nav nav-tabs'));