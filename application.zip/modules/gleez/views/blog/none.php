<h2><?php echo __('No Blogs!') ?></h2>
<p><?php echo __('There are no Blogs that have been published.'); ?></p>
