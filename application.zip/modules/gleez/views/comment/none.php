<h2><?php echo __('No Comments!'); ?></h2>
<p><?php echo __('There are no comments that have been published.'); ?></p>
