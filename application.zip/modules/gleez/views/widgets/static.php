<div class="widget1">
	<?php echo $content; ?>
</div>