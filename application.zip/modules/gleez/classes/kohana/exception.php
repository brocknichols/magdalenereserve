<?php

class Kohana_Exception extends Gleez_Exception {}