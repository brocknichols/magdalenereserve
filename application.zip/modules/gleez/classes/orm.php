<?php

class ORM extends Gleez_ORM_Core {}