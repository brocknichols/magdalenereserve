<?php

class Cache_Exception extends Gleez_Exception {}