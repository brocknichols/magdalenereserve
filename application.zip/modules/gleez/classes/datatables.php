<?php

class Datatables extends Gleez_Datatables {}