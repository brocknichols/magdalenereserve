<?php

class Model_Post extends Post {}