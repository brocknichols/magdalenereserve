<?php
/**
 * Gleez Locale Exception
 *
 * @package    Gleez\Exceptions
 * @author     Gleez Team
 * @version    1.0.1
 * @copyright  (c) 2011-2013 Gleez Technologies
 * @license    http://gleezcms.org/license  Gleez CMS License
 */
class Locale_Exception extends Gleez_Exception {}