<?php

class AutoLink extends Gleez_AutoLink {}