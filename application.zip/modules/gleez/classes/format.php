<?php

class Format extends Gleez_Format {}