<?php
/**
 * Action Class
 *
 * @package    Gleez\Action
 * @author     Gleez Team
 * @copyright  (c) 2011-2013 Gleez Technologies
 * @license    http://gleezcms.org/license  Gleez CMS License
 *
 */
class Gleez_Action {}