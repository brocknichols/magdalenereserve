<?php
/**
 * Event Class
 *
 * @package    Gleez\Event
 * @author     Sandeep Sangamreddi - Gleez
 * @copyright  (c) 2011-2013 Gleez Technologies
 * @license    http://gleezcms.org/license  Gleez CMS License
 * 
 */
class Gleez_Event {
        
	public static function Post_Save($post)
	{
		//Message::warn( Debug::vars($post) );
	}
        
}
