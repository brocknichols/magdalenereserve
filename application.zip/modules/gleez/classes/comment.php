<?php

class Comment extends Gleez_Comment {}