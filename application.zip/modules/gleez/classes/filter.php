<?php

class Filter extends Gleez_Filter {}