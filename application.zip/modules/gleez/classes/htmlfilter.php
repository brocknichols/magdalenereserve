<?php

class HTMLFilter extends Gleez_HTMLFilter {}