<?php

class Feed_Exception extends Gleez_Exception {}