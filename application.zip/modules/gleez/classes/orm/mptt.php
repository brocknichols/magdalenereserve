<?php

class ORM_MPTT extends Gleez_ORM_MPTT {}