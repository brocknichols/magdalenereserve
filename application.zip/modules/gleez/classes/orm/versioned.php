<?php

class ORM_Versioned extends Gleez_ORM_Versioned {}