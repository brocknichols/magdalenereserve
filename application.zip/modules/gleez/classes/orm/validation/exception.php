<?php

class ORM_Validation_Exception extends Gleez_ORM_Validation_Exception {}
