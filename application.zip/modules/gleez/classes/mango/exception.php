<?php

class Mango_Exception extends Gleez_Exception {}