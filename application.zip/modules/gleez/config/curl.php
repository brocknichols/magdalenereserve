<?php

return array(
	CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; Gleez v'.Gleez::VERSION.' http://gleezcms.org/)',
	CURLOPT_CONNECTTIMEOUT => 5,
	CURLOPT_TIMEOUT        => 5,
	CURLOPT_HEADER         => FALSE,
);