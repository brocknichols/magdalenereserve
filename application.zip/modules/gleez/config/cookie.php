<?php

return array(
  /** @var string Cookie salt */
  'salt'      =>  'e41eb68d5605ebcc01424519da854',

  /** @var string Cookie lifetime */
  'lifetime'  =>  Date::WEEK,
);

