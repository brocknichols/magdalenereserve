<?php

return array(
    // Breadcrumb item separator. 
    'separator'     => '&nbsp;&gt;&nbsp;',
    // Should the last item be a link or only a label?
    'last_linkable' => false
);