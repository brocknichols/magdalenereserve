<?php

return array(
	'name' => array(
		'not_empty'     => ':field must not be empty',
		'tag_available' => 'Tag :param1 already exists',
	),
);