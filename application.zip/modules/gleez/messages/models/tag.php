<?php

return array(
	'name' => array(
		'not_empty' => 'Tag name can\'t be empty',
		'tag_available' => 'Tag :param1 already exists',
	),
);