<?php

return array(
	'name' => array(
		'not_empty' => "Name of the vocabulary can't be empty",
	),
);