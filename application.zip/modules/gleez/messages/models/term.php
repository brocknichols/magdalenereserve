<?php

return array(
	'name' => array(
		'not_empty' => "Name of the group can't be empty",
	),
);
