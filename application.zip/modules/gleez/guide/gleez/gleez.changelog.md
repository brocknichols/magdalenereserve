# Gleez Changelog

## 0.4.0

Released November 1, 2010.

Initial Alpha Release