<?php defined('SYSPATH') OR die('No direct access allowed.');

class Auth_File extends Kohana_Auth_File { }