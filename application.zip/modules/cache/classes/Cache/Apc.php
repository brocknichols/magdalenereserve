<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Apc extends Kohana_Cache_Apc {}