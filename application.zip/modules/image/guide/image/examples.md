# Examples

The following are mini applications that uses the [Image] module. They are very straight forward and did not include additional code such as validations and the like. They are designed to be simple and should work out of the box.

* [Uploading image](examples/upload)
* [Cropping profile images](examples/crop)
* [Serving images with dynamic dimension](examples/dynamic)