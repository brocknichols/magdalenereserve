<?php

class Image_GD extends Kohana_Image_GD {}
